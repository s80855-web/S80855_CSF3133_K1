// Declare game variables
let gameStarted = false;
let playerName = "";
let wins = 0;
let losses = 0;
let draws = 0;
let results = [];

// Start the game and validate the player name
function startGame() {

    playerName = document.getElementById("playerName").value.trim();

    if (playerName === "") {
        alert("Please enter your name.");
        return;
    }

    // Reset previous game scores
    resetGame();

    gameStarted = true;

    // Display welcome message safely using innerHTML
    let safeName = document.createElement("span");
    safeName.textContent = playerName;

    document.getElementById("welcome").innerHTML =
        "Welcome, " + safeName.innerHTML + "!";

    // Display game start date and time
    document.getElementById("startTime").innerHTML =
        "Game started on: " + Date();
}


// Generate a random computer choice
function getComputerChoice() {

    const choices = ["rock", "paper", "scissors"];

    const randomIndex = Math.floor(Math.random() * 3);

    return choices[randomIndex];
}


// Play one round of the game
function playRound(playerChoice) {

    // Check whether the game has started
    if (!gameStarted) {
        alert("Click Start Game first.");
        return;
    }

    // Generate computer choice
    const computerChoice = getComputerChoice();

    // Change the player and computer images
    document.getElementById("playerImg").src =
        playerChoice + ".png";

    document.getElementById("computerImg").src =
        computerChoice + ".png";

    let roundResult;

    const resultDisplay = document.getElementById("result");

    // Check for a draw
    if (playerChoice === computerChoice) {

        roundResult = "Draw";

        draws++;

        resultDisplay.innerHTML = "It's a Draw!";

        resultDisplay.style.color = "grey";

    }

    // Check all winning combinations
    else if (
        (playerChoice === "rock" && computerChoice === "scissors") ||
        (playerChoice === "paper" && computerChoice === "rock") ||
        (playerChoice === "scissors" && computerChoice === "paper")
    ) {

        roundResult = "Win";

        wins++;

        resultDisplay.innerHTML = "You Win!";

        resultDisplay.style.color = "green";

    }

    // Otherwise, the computer wins
    else {

        roundResult = "Lose";

        losses++;

        resultDisplay.innerHTML = "You Lose!";

        resultDisplay.style.color = "red";

    }

    // Store the round result in an array
    results.push(roundResult);

    // Update the scoreboard
    document.getElementById("wins").innerHTML = wins;
    document.getElementById("losses").innerHTML = losses;
    document.getElementById("draws").innerHTML = draws;

    // Convert choices to capitalised words
    let playerText =
        playerChoice.charAt(0).toUpperCase() +
        playerChoice.slice(1);

    let computerText =
        computerChoice.charAt(0).toUpperCase() +
        computerChoice.slice(1);

    // Add a new row to the history table
    document.getElementById("historyBody").innerHTML +=
        "<tr>" +
        "<td>" + results.length + "</td>" +
        "<td>" + playerText + "</td>" +
        "<td>" + computerText + "</td>" +
        "<td class='" + roundResult.toLowerCase() + "'>" +
        roundResult + "</td>" +
        "</tr>";

    // Clear the previous summary
    document.getElementById("summary").innerHTML = "";
}


// Display the game summary
function showSummary() {

    // Check whether any rounds have been played
    if (results.length === 0) {
        alert("Please play at least one round first.");
        return;
    }

    let totalWins = 0;

    // Count wins using a for loop
    for (let i = 0; i < results.length; i++) {

        if (results[i] === "Win") {
            totalWins++;
        }

    }

    // Calculate the rounded win percentage
    let winPercentage =
        Math.round((totalWins / results.length) * 100);

    // Display the summary
    document.getElementById("summary").innerHTML =
        "You played " + results.length +
        " rounds and won " + winPercentage + "%." +
        "<br>Wins: " + wins +
        " | Losses: " + losses +
        " | Draws: " + draws;

}


// Reset the game
function resetGame() {

    // Reset all game variables
    wins = 0;
    losses = 0;
    draws = 0;
    results = [];
    gameStarted = false;

    // Reset scoreboard values
    document.getElementById("wins").innerHTML = 0;
    document.getElementById("losses").innerHTML = 0;
    document.getElementById("draws").innerHTML = 0;

    // Clear game messages and history
    document.getElementById("historyBody").innerHTML = "";
    document.getElementById("result").innerHTML = "";
    document.getElementById("summary").innerHTML = "";
    document.getElementById("welcome").innerHTML = "";
    document.getElementById("startTime").innerHTML = "";

    // Reset both images
    document.getElementById("playerImg").src = "rock.png";
    document.getElementById("computerImg").src = "rock.png";
}