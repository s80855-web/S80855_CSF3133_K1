// Questions array
const questions = [
    {
        question: "What does HTML stand for?",
        options: [
            "Hyper Text Markup Language",
            "High Text Machine Language",
            "Hyper Transfer Markup Language",
            "Home Tool Markup Language"
        ],
        answer: 0
    },
    {
        question: "Which language is used to style a webpage?",
        options: ["HTML", "JavaScript", "CSS", "Python"],
        answer: 2
    },
    {
        question: "Which HTML tag is used to insert JavaScript?",
        options: ["<javascript>", "<script>", "<js>", "<code>"],
        answer: 1
    },
    {
        question: "Which method selects an HTML element using its ID?",
        options: [
            "getElementByClass()",
            "getElement()",
            "selectElement()",
            "getElementById()"
        ],
        answer: 3
    },
    {
        question: "Which JavaScript function displays a pop-up message?",
        options: ["alert()", "print()", "display()", "message()"],
        answer: 0
    },
    {
        question: "Which event occurs when a user clicks a button?",
        options: ["onload", "onchange", "onclick", "onmouseover"],
        answer: 2
    },
    {
        question: "Which CSS property changes the text colour?",
        options: [
            "background-color",
            "font-style",
            "text-size",
            "color"
        ],
        answer: 3
    },
    {
        question: "Which function generates a random decimal number?",
        options: [
            "Math.floor()",
            "Math.random()",
            "Math.round()",
            "Math.ceil()"
        ],
        answer: 1
    },
    {
        question: "Which file extension is used for JavaScript files?",
        options: [".html", ".css", ".java", ".js"],
        answer: 3
    },
    {
        question: "What is the purpose of client-side validation?",
        options: [
            "To change the webpage colour",
            "To create images",
            "To validate input before submitting it to the server",
            "To close the browser"
        ],
        answer: 2
    }
];

let shuffledQuestions = [];
let currentQuestion = 0;
let score = 0;
let timeLeft = 15;
let timer;
let answered = false;


// Randomly shuffle the questions
function shuffleQuestions() {
    shuffledQuestions = [...questions];

    for (let i = shuffledQuestions.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));

        [shuffledQuestions[i], shuffledQuestions[j]] =
        [shuffledQuestions[j], shuffledQuestions[i]];
    }
}


// Start the countdown timer
function startTimer() {
    clearInterval(timer);

    timeLeft = 15;

    const timerDisplay = document.getElementById("timer");

    timerDisplay.textContent = "Time Left: " + timeLeft + "s";
    timerDisplay.style.color = "#92400e";
    timerDisplay.style.backgroundColor = "#fef3c7";

    timer = setInterval(function () {

        timeLeft--;

        timerDisplay.textContent = "Time Left: " + timeLeft + "s";

        if (timeLeft <= 5) {
            timerDisplay.style.color = "#991b1b";
            timerDisplay.style.backgroundColor = "#fee2e2";
        }

        if (timeLeft <= 0) {
            clearInterval(timer);
            timeUp();
        }

    }, 1000);
}


// Display the current question and answer options
function displayQuestion() {

    answered = false;

    const question = shuffledQuestions[currentQuestion];

    document.getElementById("question-number").textContent =
        "Question " + (currentQuestion + 1) +
        " of " + shuffledQuestions.length;

    document.getElementById("question").textContent =
        question.question;

    document.getElementById("feedback").textContent = "";

    document.getElementById("submit-btn").disabled = false;
    document.getElementById("next-btn").disabled = true;

    document.getElementById("next-btn").textContent =
        currentQuestion === shuffledQuestions.length - 1
        ? "Finish Quiz"
        : "Next Question";

    const percentage =
        ((currentQuestion + 1) / shuffledQuestions.length) * 100;

    document.getElementById("progress").style.width =
        percentage + "%";

    const optionsContainer = document.getElementById("options");

    optionsContainer.innerHTML = "";

    question.options.forEach(function (option, index) {

        const label = document.createElement("label");
        label.className = "option";

        const input = document.createElement("input");

        input.type = "radio";
        input.name = "answer";
        input.value = index;

        const text = document.createElement("span");
        text.textContent = option;

        label.appendChild(input);
        label.appendChild(text);

        optionsContainer.appendChild(label);
    });

    startTimer();
}


// Check the selected answer and update the score
function checkAnswer() {

    if (answered) {
        return;
    }

    const selectedAnswer =
        document.querySelector('input[name="answer"]:checked');

    const feedback = document.getElementById("feedback");

    if (!selectedAnswer) {
        feedback.textContent = "Please select an answer first.";
        feedback.style.color = "#d97706";
        return;
    }

    clearInterval(timer);

    answered = true;

    const userAnswer = Number(selectedAnswer.value);
    const question = shuffledQuestions[currentQuestion];
    const correctAnswer = question.answer;

    const options = document.querySelectorAll(".option");

    if (userAnswer === correctAnswer) {

        score++;

        feedback.textContent = "Correct! Well done.";
        feedback.style.color = "#15803d";

        options[userAnswer].classList.add("correct");

    } else {

        feedback.textContent =
            "Incorrect! The correct answer is: " +
            question.options[correctAnswer];

        feedback.style.color = "#dc2626";

        options[userAnswer].classList.add("incorrect");
        options[correctAnswer].classList.add("correct");
    }

    disableAnswers();
}


// Handle questions when the timer reaches zero
function timeUp() {

    if (answered) {
        return;
    }

    answered = true;

    const question = shuffledQuestions[currentQuestion];
    const feedback = document.getElementById("feedback");
    const options = document.querySelectorAll(".option");

    feedback.textContent =
        "Time's up! The correct answer is: " +
        question.options[question.answer];

    feedback.style.color = "#dc2626";

    options[question.answer].classList.add("correct");

    disableAnswers();
}


// Prevent the user from changing a submitted answer
function disableAnswers() {

    const inputs =
        document.querySelectorAll('input[name="answer"]');

    inputs.forEach(function (input) {
        input.disabled = true;
    });

    document.getElementById("submit-btn").disabled = true;
    document.getElementById("next-btn").disabled = false;
}


// Move to the next question
function nextQuestion() {

    if (!answered) {
        return;
    }

    clearInterval(timer);

    currentQuestion++;

    if (currentQuestion < shuffledQuestions.length) {

        displayQuestion();

    } else {

        showResult();
    }
}


// Display the final score
function showResult() {

    clearInterval(timer);

    document.getElementById("quiz-container").hidden = true;
    document.getElementById("result").hidden = false;

    const percentage =
        Math.round((score / shuffledQuestions.length) * 100);

    document.getElementById("score").textContent =
        "Your Score: " + score + " / " +
        shuffledQuestions.length + " (" + percentage + "%)";

    const resultMessage =
        document.getElementById("result-message");

    if (percentage === 100) {

        resultMessage.textContent =
            "Excellent! You achieved a perfect score!";

    } else if (percentage >= 70) {

        resultMessage.textContent =
            "Great job! You have a good understanding.";

    } else if (percentage >= 50) {

        resultMessage.textContent =
            "Good effort! Keep practising.";

    } else {

        resultMessage.textContent =
            "Keep learning and try again!";
    }
}


// Start or restart the quiz
function startQuiz() {

    clearInterval(timer);

    currentQuestion = 0;
    score = 0;
    answered = false;

    document.getElementById("quiz-container").hidden = false;
    document.getElementById("result").hidden = true;

    shuffleQuestions();
    displayQuestion();
}


// Start the quiz when the webpage loads
startQuiz();