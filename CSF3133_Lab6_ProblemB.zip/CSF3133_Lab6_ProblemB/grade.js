// ================================================
// ERROR IDENTIFICATION
// ================================================

// Error 1 (grade.html, Line 9):
// onsubmit="checkMark()" does not return the function result.
// Correction: onsubmit="return checkMark()".

// Error 2 (grade.html, Line 17):
// showtable() has incorrect capitalisation.
// Correction: showTable().

// Error 3 (grade.html, Line 19):
// grades.js is an incorrect filename.
// Correction: grade.js.

// Error 4 (grade.js, Line 5):
// name = "" assigns an empty string instead of comparing.
// Correction: name === "".

// Error 5 (grade.js, Line 9):
// isNan() is incorrectly capitalised.
// Correction: isNaN().

// Error 6 (grade.js, Line 14):
// && is incorrect because a mark cannot be below 0
// and above 100 at the same time.
// Correction: use || instead.

// Error 7 (grade.js, Line 28):
// getElementByID() is incorrectly capitalised.
// Correction: getElementById().

// Error 8 (grade.js, Line 30):
// style.colour is not a valid JavaScript style property.
// Correction: style.color.

// Error 9 (grade.js, Line 31):
// return true allows the form to submit and refresh.
// Correction: return false.

// Error 10 (grade.js, Line 38):
// The loop starts at index 1 and skips grade A.
// Correction: start the loop at index 0.

// Error 11 (grade.js, Line 42):
// innerHtml is incorrectly capitalised.
// Correction: innerHTML.


// ================================================
// CHECK STUDENT MARK AND CALCULATE GRADE
// ================================================

function checkMark() {

    // Retrieve student name and mark
    let name = document.forms["gradeForm"]["name"].value.trim();

    let mark = document.forms["gradeForm"]["mark"].value.trim();

    // Clear previous results
    document.getElementById("result").textContent = "";
    document.getElementById("checkedTime").textContent = "";

    // Validate empty student name
    if (name === "") {

        alert("Name must be filled out.");

        return false;
    }

    // New feature: validate empty mark
    if (mark === "") {

        alert("Mark field cannot be empty.");

        return false;
    }

    // Validate non-numeric input
    if (isNaN(mark)) {

        alert("Please enter a valid numeric value.");

        return false;
    }

    // Convert the mark into a number
    mark = Number(mark);

    // Validate the mark range
    if (mark < 0 || mark > 100) {

        alert("Mark must be between 0 and 100.");

        return false;
    }

    // Determine the student's grade
    let grade;

    if (mark >= 80) {

        grade = "A";

    } else if (mark >= 65) {

        grade = "B";

    } else if (mark >= 50) {

        grade = "C";

    } else {

        grade = "F";

    }

    // Display the grade result
    let result = document.getElementById("result");

    result.textContent = name + " got grade " + grade;

    // New feature: change result colour according to grade
    if (grade === "A" || grade === "B") {

        result.style.color = "green";

    } else if (grade === "C") {

        result.style.color = "orange";

    } else {

        result.style.color = "red";

    }

    // New feature: display current date and time
    document.getElementById("checkedTime").innerHTML =
        "Checked on: " + Date();

    // Prevent the form from refreshing the page
    return false;
}


// ================================================
// DISPLAY THE GRADE TABLE
// ================================================

function showTable() {

    // Arrays containing grades and mark ranges
    let grades = ["A", "B", "C", "F"];

    let ranges = ["80-100", "65-79", "50-64", "0-49"];

    // Create the table header
    let tableHTML = "<table>";

    tableHTML += "<tr><th>Grade</th><th>Mark Range</th></tr>";

    // Generate all four grade rows using a for loop
    for (let i = 0; i < grades.length; i++) {

        tableHTML +=
            "<tr><td>" + grades[i] +
            "</td><td>" + ranges[i] +
            "</td></tr>";

    }

    tableHTML += "</table>";

    // Display the completed table
    document.getElementById("tableContainer").innerHTML =
        tableHTML;
}


// ================================================
// GENERATE A RANDOM MARK
// ================================================

function randomMark() {

    // Generate a random whole number from 0 to 100
    let randomNumber = Math.floor(Math.random() * 101);

    // Insert the random number into the mark field
    document.getElementById("mark").value = randomNumber;
}